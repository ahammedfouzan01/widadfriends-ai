import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { newsPosts } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  try {
    const posts = await db.select().from(newsPosts).orderBy(desc(newsPosts.pinned), desc(newsPosts.publishedAt));
    return NextResponse.json({ posts });
  } catch {
    return NextResponse.json({ posts: [] });
  }
}

export async function POST(req: NextRequest) {
  try {
    const b = await req.json();
    if (!b.title?.trim()) return NextResponse.json({ error: "Title required" }, { status: 400 });
    const [row] = await db.insert(newsPosts).values({
      title: String(b.title).slice(0, 160),
      excerpt: String(b.excerpt ?? "").slice(0, 400),
      content: String(b.content ?? b.excerpt ?? "").slice(0, 8000),
      imageUrl: String(b.imageUrl ?? "").slice(0, 800),
      author: String(b.author ?? "Union Media").slice(0, 80),
      pinned: Boolean(b.pinned),
    }).returning();
    return NextResponse.json({ post: row });
  } catch {
    return NextResponse.json({ error: "Save failed" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const id = new URL(req.url).searchParams.get("id");
    if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });
    const b = await req.json();
    const [row] = await db.update(newsPosts).set({
      title: String(b.title).slice(0, 160),
      excerpt: String(b.excerpt ?? "").slice(0, 400),
      content: String(b.content ?? "").slice(0, 8000),
      imageUrl: String(b.imageUrl ?? "").slice(0, 800),
      author: String(b.author ?? "Union Media").slice(0, 80),
      pinned: Boolean(b.pinned),
    }).where(eq(newsPosts.id, id)).returning();
    return NextResponse.json({ post: row });
  } catch {
    return NextResponse.json({ error: "Update failed" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const id = new URL(req.url).searchParams.get("id");
    if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });
    await db.delete(newsPosts).where(eq(newsPosts.id, id));
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Delete failed" }, { status: 500 });
  }
}
