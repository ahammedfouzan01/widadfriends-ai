"use client";

import { useEffect, useState } from "react";

/* ---------- icons (stroke, lucide-style) ---------- */
export function Icon({ d, size = 18, sw = 1.8 }: { d: string; size?: number; sw?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d={d} />
    </svg>
  );
}
export const I = {
  moon: "M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8z",
  sun: "M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10zm0-15v2m0 16v2M4.2 4.2l1.4 1.4m12.8 12.8 1.4 1.4M1 12h2m18 0h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4",
  shield: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z",
  shieldCheck: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10zm-3-9 2 2 4-4",
  sparkles: "M12 3v3m0 12v3M5.6 5.6l2.1 2.1m8.6 8.6 2.1 2.1M3 12h3m12 0h3M5.6 18.4l2.1-2.1m8.6-8.6 2.1-2.1M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z",
  crown: "M3 18h18M4 17l-1-9 5 4 4-7 4 7 5-4-1 9z",
  clipboard: "M9 4h6v3H9zM9 4H7a1 1 0 0 0-1 1v15a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V5a1 1 0 0 0-1-1h-2m-9 9 2 2 4-4",
  trophy: "M8 21h8m-4-4v4M7 4h10v5a5 5 0 0 1-10 0zM7 6H4a1 1 0 0 0-1 1c0 2 1.5 3.5 4 3.5M17 6h3a1 1 0 0 1 1 1c0 2-1.5 3.5-4 3.5",
  users: "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2m22 0v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8M13 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0z",
  image: "M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2zm0 13 5-5 3 3 3-3 5 5M9 8.5a1.5 1.5 0 1 0 0 .01",
  news: "M4 5h12v14H4zM16 8h3l-3-3m3 3v9a1 1 0 0 1-1 1h-5M7 9h6M7 13h6M7 17h4",
  chat: "M21 12a8 8 0 0 1-8 8H4l2-3a8 8 0 1 1 15-5z",
  send: "M22 2 11 13M22 2l-7 20-4-9-9-4z",
  search: "M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16zm10 2-4.3-4.3",
  plus: "M12 5v14M5 12h14",
  x: "M18 6 6 18M6 6l12 12",
  edit: "M17 3a2.8 2.8 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5z",
  trash: "M3 6h18M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2m3 0-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6",
  menu: "M4 7h16M4 12h16M4 17h16",
  arrowUp: "M12 19V5m-7 7 7-7 7 7",
  arrowRight: "M5 12h14m-6-6 6 6-6 6",
  check: "M20 6 9 17l-5-5",
  lock: "M5 11h14v10H5zM8 11V7a4 4 0 0 1 8 0v4",
  logout: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4m7 14 5-5-5-5m5 5H9",
  camera: "M4 7h3l2-2h6l2 2h3a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm8 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z",
  book: "M4 19.5A2.5 2.5 0 0 1 6.5 17H20V2H6.5A2.5 2.5 0 0 0 4 4.5zm0 0A2.5 2.5 0 0 0 6.5 22H20v-5",
  pin: "M12 17v5m-3-5h6l1-7H8zm2-7V3h2v2m-5 0h8",
  calendar: "M8 2v4m8-4v4M3 9h18M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z",
};

/* ---------- widad emblem ---------- */
export function WidadMark({ size = 30, glow = false }: { size?: number; glow?: boolean }) {
  return (
    <svg width={size} height={size * 1.15} viewBox="0 0 48 56" fill="none" aria-hidden style={glow ? { filter: "drop-shadow(0 6px 22px rgba(201,154,63,.55))" } : undefined}>
      <defs>
        <linearGradient id="wg" x1="0" y1="0" x2="48" y2="56">
          <stop offset="0" stopColor="#8A5A1B" />
          <stop offset="0.45" stopColor="#D9B45C" />
          <stop offset="0.75" stopColor="#E8C46A" />
          <stop offset="1" stopColor="#9A6B1F" />
        </linearGradient>
      </defs>
      <path d="M24 2 44 12 24 22 4 12Z" fill="url(#wg)" opacity="0.95" />
      <path d="M10 20 24 27 38 20l3 2.5L24 31 3 22.5Z" fill="url(#wg)" opacity="0.88" />
      <path d="M8 28.5 24 36 40 28.5l2.5 2.5L24 40 5.5 31Z" fill="url(#wg)" opacity="0.8" />
      <path d="M12 37.5 24 43l12-5.5 1.8 2L24 46 10.2 39.5Z" fill="url(#wg)" opacity="0.72" />
    </svg>
  );
}

/* ---------- toast ---------- */
export type Toast = { id: number; msg: string; kind: "ok" | "err" };
export function Toasts({ toasts }: { toasts: Toast[] }) {
  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[120] flex flex-col items-center gap-2 pointer-events-none">
      {toasts.map((t) => (
        <div key={t.id} className="toast-in pointer-events-auto flex items-center gap-2 px-4 py-2.5 rounded-full text-[13px] font-medium shadow-xl border" style={{ background: "var(--card)", borderColor: "var(--card-border)", color: "var(--ink)" }}>
          <span className="grid place-items-center w-5 h-5 rounded-full" style={{ background: t.kind === "ok" ? "#2f7d3b" : "#b3372f", color: "#fff" }}>
            <Icon d={t.kind === "ok" ? I.check : I.x} size={12} sw={3} />
          </span>
          {t.msg}
        </div>
      ))}
    </div>
  );
}

/* ---------- navbar ---------- */
const LINKS = [
  { id: "home", label: "Home" },
  { id: "committee", label: "Committee" },
  { id: "wings", label: "Wings" },
  { id: "gallery", label: "Gallery" },
  { id: "news", label: "News" },
  { id: "chat", label: "Chat" },
];

export function Navbar({ active, dark, onToggleDark, onAdmin, isAdmin }: { active: string; dark: boolean; onToggleDark: () => void; onAdmin: () => void; isAdmin: boolean }) {
  const [open, setOpen] = useState(false);
  const go = (id: string) => {
    setOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };
  return (
    <header className="sticky top-0 z-[80] border-b" style={{ background: "var(--nav-bg)", backdropFilter: "blur(14px)", borderColor: "var(--card-border)" }}>
      <div className="max-w-6xl mx-auto px-5 h-[68px] flex items-center justify-between gap-4">
        <button onClick={() => go("home")} className="flex items-center gap-2.5 group">
          <WidadMark size={26} />
          <span className="text-left leading-none">
            <span className="font-display block text-[19px] font-semibold tracking-wide lowercase" style={{ color: "var(--gold-600)" }}>widad</span>
            <span className="block text-[8px] tracking-[0.3em] uppercase font-semibold" style={{ color: "var(--ink-faint)" }}>friends · 2026</span>
          </span>
        </button>
        <nav className="hidden md:flex items-center gap-7">
          {LINKS.map((l) => (
            <button key={l.id} onClick={() => go(l.id)} className={`nav-link uppercase ${active === l.id ? "active" : ""}`}>
              {l.label}
            </button>
          ))}
        </nav>
        <div className="flex items-center gap-2.5">
          <button onClick={onToggleDark} aria-label="Toggle theme" className="w-9 h-9 grid place-items-center rounded-full border transition hover:scale-105" style={{ borderColor: "var(--card-border)", color: "var(--ink-soft)", background: "color-mix(in srgb, var(--card) 60%, transparent)" }}>
            <Icon d={dark ? I.sun : I.moon} size={16} />
          </button>
          <button onClick={onAdmin} className="hidden sm:inline-flex items-center gap-1.5 text-[11px] font-bold tracking-[0.14em] uppercase px-4 py-2 rounded-full text-[#fff8e7]" style={{ background: "linear-gradient(135deg,#9a6b1f,#b07c2a)", boxShadow: "0 6px 18px rgba(176,124,42,.35)" }}>
            <Icon d={isAdmin ? I.logout : I.shield} size={13} sw={2.2} />
            {isAdmin ? "Dashboard" : "Admin"}
          </button>
          <button onClick={() => setOpen(!open)} className="md:hidden w-9 h-9 grid place-items-center rounded-full border" style={{ borderColor: "var(--card-border)", color: "var(--ink-soft)" }} aria-label="Menu">
            <Icon d={open ? I.x : I.menu} size={17} />
          </button>
        </div>
      </div>
      {open && (
        <div className="md:hidden border-t px-5 py-3 flex flex-col gap-1" style={{ borderColor: "var(--card-border)", background: "var(--nav-bg)" }}>
          {LINKS.map((l) => (
            <button key={l.id} onClick={() => go(l.id)} className="text-left py-2.5 text-[12px] font-semibold tracking-[0.18em] uppercase" style={{ color: active === l.id ? "var(--gold-600)" : "var(--ink-soft)" }}>
              {l.label}
            </button>
          ))}
          <button onClick={onAdmin} className="mt-1 mb-2 inline-flex items-center justify-center gap-1.5 text-[11px] font-bold tracking-[0.14em] uppercase px-4 py-2.5 rounded-full text-[#fff8e7]" style={{ background: "linear-gradient(135deg,#9a6b1f,#b07c2a)" }}>
            <Icon d={I.shield} size={13} sw={2.2} /> {isAdmin ? "Dashboard" : "Admin"}
          </button>
        </div>
      )}
    </header>
  );
}

/* ---------- hero ---------- */
export function Hero({ counts }: { counts: { committee: number; wings: number; gallery: number; news: number } }) {
  const go = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  return (
    <section id="home" className="relative overflow-hidden">
      <div className="max-w-6xl mx-auto px-5 pt-14 pb-6 text-center">
        <span className="pill-badge">
          <Icon d={I.trophy} size={13} />
          Class 2 Union · 2026
        </span>
        <h1 className="font-display gold-text font-800 mt-7 leading-[0.95] select-none" style={{ fontWeight: 800, fontSize: "clamp(56px, 11vw, 128px)", letterSpacing: "0.01em" }}>
          WIDAD
          <br />
          FRIENDS
        </h1>
        <p className="mt-6 text-[11px] sm:text-xs font-bold tracking-[0.32em] uppercase" style={{ color: "var(--ink-soft)" }}>
          23rd Batch Union · BUAC Maniyyor
        </p>
        <p className="mt-2 text-[10px] sm:text-[11px] font-semibold tracking-[0.26em] uppercase" style={{ color: "var(--ink-faint)" }}>
          Worthy Individuals for Da&apos;wa, Arts and Discipline
        </p>
        <div className="mt-8 flex items-center justify-center gap-3 flex-wrap">
          <button className="btn-gold" onClick={() => go("committee")}>
            Meet the committee <Icon d={I.arrowRight} size={15} />
          </button>
          <button className="btn-ghost" onClick={() => go("wings")}>
            Explore wings
          </button>
        </div>
        <div className="mt-12 flex justify-center">
          <div className="float-slow flex flex-col items-center gap-1.5 opacity-90">
            <WidadMark size={64} glow />
            <span className="font-display lowercase text-[22px] font-semibold" style={{ color: "var(--gold-600)" }}>widad</span>
          </div>
        </div>
      </div>
      {/* stats */}
      <div className="max-w-4xl mx-auto px-5 pb-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard icon={I.shield} value={counts.wings} label="Wings" />
          <StatCard icon={I.sparkles} value={counts.committee} label="Committee" />
          <StatCard icon={I.crown} value={counts.news} label="News & Events" />
          <StatCard icon={I.clipboard} value={counts.gallery} label="Gallery" />
        </div>
      </div>
    </section>
  );
}

function StatCard({ icon, value, label }: { icon: string; value: number; label: string }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    let raf = 0;
    const t0 = performance.now();
    const dur = 1100;
    const tick = (t: number) => {
      const p = Math.min(1, (t - t0) / dur);
      setN(Math.round(value * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value]);
  return (
    <div className="card-cream px-4 py-7 text-center">
      <div className="mx-auto w-fit" style={{ color: "var(--gold-600)" }}>
        <Icon d={icon} size={20} />
      </div>
      <div className="stat-num gold-text mt-2">{n}</div>
      <div className="mt-1.5 text-[10px] font-bold tracking-[0.24em] uppercase" style={{ color: "var(--ink-soft)" }}>{label}</div>
    </div>
  );
}

/* ---------- section heading ---------- */
export function Heading({ eyebrow, title, sub }: { eyebrow: string; title: string; sub?: string }) {
  return (
    <div className="text-center max-w-2xl mx-auto mb-10">
      <p className="eyebrow">{eyebrow}</p>
      <h2 className="font-display mt-3 font-bold gold-text" style={{ fontSize: "clamp(30px,4.5vw,46px)", lineHeight: 1.05 }}>{title}</h2>
      {sub && <p className="mt-3 text-[14px] leading-relaxed" style={{ color: "var(--ink-soft)" }}>{sub}</p>}
    </div>
  );
}
