import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { wings } from "@/db/schema";
import { asc, eq } from "drizzle-orm";

export async function GET() {
  try {
    const rows = await db.select().from(wings).orderBy(asc(wings.createdAt));
    return NextResponse.json({ wings: rows });
  } catch {
    return NextResponse.json({ wings: [] });
  }
}

export async function POST(req: NextRequest) {
  try {
    const b = await req.json();
    if (!b.name?.trim()) return NextResponse.json({ error: "Name required" }, { status: 400 });
    const [row] = await db.insert(wings).values({
      name: String(b.name).slice(0, 80),
      slug: String(b.slug ?? b.name).toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 80),
      tagline: String(b.tagline ?? "").slice(0, 120),
      description: String(b.description ?? "").slice(0, 2000),
      icon: String(b.icon ?? "sparkles").slice(0, 30),
      leaderName: String(b.leaderName ?? "").slice(0, 80),
      memberCount: Number(b.memberCount) || 0,
      color: String(b.color ?? "#B07C2A").slice(0, 20),
    }).returning();
    return NextResponse.json({ wing: row });
  } catch {
    return NextResponse.json({ error: "Save failed" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const id = new URL(req.url).searchParams.get("id");
    if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });
    const b = await req.json();
    const [row] = await db.update(wings).set({
      name: String(b.name).slice(0, 80),
      tagline: String(b.tagline ?? "").slice(0, 120),
      description: String(b.description ?? "").slice(0, 2000),
      icon: String(b.icon ?? "sparkles").slice(0, 30),
      leaderName: String(b.leaderName ?? "").slice(0, 80),
      memberCount: Number(b.memberCount) || 0,
      color: String(b.color ?? "#B07C2A").slice(0, 20),
    }).where(eq(wings.id, id)).returning();
    return NextResponse.json({ wing: row });
  } catch {
    return NextResponse.json({ error: "Update failed" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const id = new URL(req.url).searchParams.get("id");
    if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });
    await db.delete(wings).where(eq(wings.id, id));
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Delete failed" }, { status: 500 });
  }
}
