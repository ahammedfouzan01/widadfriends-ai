"use client";

import { useCallback, useEffect, useState } from "react";
import { Navbar, Hero, Toasts, type Toast } from "./chrome";
import { Committee, Wings, Gallery, News } from "./sections";
import { Chat, Footer, AdminPanel } from "./interactive";
import type { CommitteeMember, Wing, GalleryItem, NewsPost } from "@/db/schema";

let toastId = 1;

export default function WidadSite() {
  const [dark, setDark] = useState(false);
  const [active, setActive] = useState("home");
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [adminOpen, setAdminOpen] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  const [committee, setCommittee] = useState<CommitteeMember[]>([]);
  const [wings, setWings] = useState<Wing[]>([]);
  const [gallery, setGallery] = useState<GalleryItem[]>([]);
  const [news, setNews] = useState<NewsPost[]>([]);
  const [chatCount, setChatCount] = useState(0);

  const toast = useCallback((msg: string, kind: "ok" | "err" = "ok") => {
    const id = toastId++;
    setToasts((t) => [...t, { id, msg, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2800);
  }, []);

  const load = useCallback(async () => {
    try {
      const [c, w, g, n, ch] = await Promise.all([
        fetch("/api/committee", { cache: "no-store" }).then((r) => r.json()).catch(() => ({ members: [] })),
        fetch("/api/wings", { cache: "no-store" }).then((r) => r.json()).catch(() => ({ wings: [] })),
        fetch("/api/gallery", { cache: "no-store" }).then((r) => r.json()).catch(() => ({ items: [] })),
        fetch("/api/news", { cache: "no-store" }).then((r) => r.json()).catch(() => ({ posts: [] })),
        fetch("/api/chat", { cache: "no-store" }).then((r) => r.json()).catch(() => ({ messages: [] })),
      ]);
      setCommittee(c.members ?? []);
      setWings(w.wings ?? []);
      setGallery(g.items ?? []);
      setNews(n.posts ?? []);
      setChatCount((ch.messages ?? []).length);
    } catch {
      /* offline */
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    try {
      setDark(document.documentElement.classList.contains("dark"));
      setIsAdmin(sessionStorage.getItem("widad-admin") === "1");
    } catch {}
    // ensure seed then load
    fetch("/api/site").catch(() => {}).finally(() => load());
  }, [load]);

  useEffect(() => {
    const onScroll = () => {
      const ids = ["home", "committee", "wings", "gallery", "news", "chat"];
      let cur = "home";
      for (const id of ids) {
        const el = document.getElementById(id);
        if (el && el.getBoundingClientRect().top < 140) cur = id;
      }
      setActive(cur);
      // reveal on scroll
      document.querySelectorAll(".reveal").forEach((el) => {
        if (el.getBoundingClientRect().top < window.innerHeight - 60) el.classList.add("visible");
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const toggleDark = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    try { localStorage.setItem("widad-theme", next ? "dark" : "light"); } catch {}
  };

  return (
    <div className="min-h-screen">
      <Navbar active={active} dark={dark} onToggleDark={toggleDark} onAdmin={() => setAdminOpen(true)} isAdmin={isAdmin} />

      {loading ? (
        <div className="max-w-6xl mx-auto px-5 pt-20 pb-32 text-center">
          <div className="pill-badge mx-auto shimmer">Loading union…</div>
          <h1 className="font-display gold-text font-bold mt-6" style={{ fontSize: "clamp(48px,9vw,96px)" }}>WIDAD<br />FRIENDS</h1>
        </div>
      ) : (
        <>
          <Hero counts={{ committee: committee.length, wings: wings.length, gallery: gallery.length, news: news.length }} />
          {/* marquee strip */}
          <div className="max-w-6xl mx-auto px-5 mt-6 overflow-hidden">
            <div className="card-cream px-5 py-3 overflow-hidden">
              <div className="marquee-track text-[11px] font-bold tracking-[0.22em] uppercase" style={{ color: "var(--gold-700)" }}>
                {[0, 1].map((k) => (
                  <span key={k} className="flex gap-8 pr-8 shrink-0">
                    <span>Da&apos;wa with wisdom</span><span>·</span><span>Arts with adab</span><span>·</span><span>Discipline with love</span><span>·</span><span>23rd Batch</span><span>·</span><span>Class 2 Union 2026</span><span>·</span>
                  </span>
                ))}
              </div>
            </div>
          </div>
          <div className="reveal"><Committee members={committee} wings={wings} onToast={toast} /></div>
          <div className="reveal"><Wings wings={wings} members={committee} /></div>
          <div className="reveal"><Gallery items={gallery} isAdmin={isAdmin} onChanged={load} onToast={toast} /></div>
          <div className="reveal"><News posts={news} isAdmin={isAdmin} onChanged={load} onToast={toast} /></div>
          <div className="reveal"><Chat isAdmin={isAdmin} onToast={toast} onCount={load} /></div>
        </>
      )}

      <Footer />

      <button
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        aria-label="Back to top"
        className="fixed bottom-6 right-6 z-[90] w-11 h-11 grid place-items-center rounded-full text-[#fff8e7] shadow-xl transition hover:scale-110"
        style={{ background: "linear-gradient(135deg,#9a6b1f,#b07c2a)" }}
      >
        ↑
      </button>

      <AdminPanel
        open={adminOpen}
        onClose={() => { setAdminOpen(false); try { setIsAdmin(sessionStorage.getItem("widad-admin") === "1"); } catch {} }}
        data={{ committee, wings, gallery, news, chat: chatCount }}
        onChanged={load}
        onToast={toast}
      />
      <Toasts toasts={toasts} />
    </div>
  );
}
