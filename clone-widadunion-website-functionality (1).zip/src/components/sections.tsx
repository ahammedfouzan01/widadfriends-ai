"use client";

import { useMemo, useState } from "react";
import { Heading, Icon, I } from "./chrome";
import type { CommitteeMember, Wing, GalleryItem, NewsPost } from "@/db/schema";

/* ---------- helpers ---------- */
export function initials(name: string) {
  return name.split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase();
}
export function timeAgo(d: string | Date) {
  const t = new Date(d).getTime();
  const s = Math.max(1, Math.floor((Date.now() - t) / 1000));
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  const days = Math.floor(s / 86400);
  if (days === 1) return "yesterday";
  if (days < 30) return `${days}d ago`;
  return new Date(d).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
}
const WING_ICON: Record<string, string> = {
  moon: I.moon, sparkles: I.sparkles, shield: I.shield, camera: I.camera, trophy: I.trophy, book: I.book,
  star: I.sparkles, users: I.users, news: I.news,
};

/* ---------- committee ---------- */
export function Committee({ members, wings, onToast }: { members: CommitteeMember[]; wings: Wing[]; onToast: (m: string, k?: "ok" | "err") => void }) {
  const [q, setQ] = useState("");
  const [wing, setWing] = useState("All");
  const [sel, setSel] = useState<CommitteeMember | null>(null);
  const list = useMemo(() => {
    return [...members]
      .sort((a, b) => a.displayOrder - b.displayOrder)
      .filter((m) => (wing === "All" || m.wing === wing) && (m.name.toLowerCase().includes(q.toLowerCase()) || m.role.toLowerCase().includes(q.toLowerCase())));
  }, [members, q, wing]);
  const wingNames = ["All", ...Array.from(new Set(members.map((m) => m.wing)))];
  return (
    <section id="committee" className="section-pad scroll-mt-20">
      <div className="max-w-6xl mx-auto px-5">
        <Heading eyebrow="The council" title="Meet the Committee" sub="Nine trusted faces carrying the amanah of Class 2 — elected to serve Da'wa, Arts and Discipline." />
        <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between mb-6">
          <div className="relative flex-1 max-w-md">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2" style={{ color: "var(--ink-faint)" }}><Icon d={I.search} size={16} /></span>
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name or role…" className="field pl-10" />
          </div>
          <div className="flex gap-2 flex-wrap">
            {wingNames.map((w) => (
              <button key={w} onClick={() => setWing(w)} className="px-3.5 py-1.5 rounded-full text-[11px] font-bold tracking-wide border transition" style={wing === w ? { background: "var(--gold-600)", color: "#fff8e7", borderColor: "transparent" } : { borderColor: "var(--card-border)", color: "var(--ink-soft)", background: "var(--card)" }}>
                {w}
              </button>
            ))}
          </div>
        </div>
        {list.length === 0 && <p className="text-center py-14 text-sm" style={{ color: "var(--ink-faint)" }}>No members match your search.</p>}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {list.map((m) => (
            <button key={m.id} onClick={() => setSel(m)} className="card-cream p-6 text-left group hover:-translate-y-1 transition-transform duration-300">
              <div className="flex items-start gap-4">
                <div className="w-16 h-16 rounded-2xl grid place-items-center font-display font-bold text-[20px] shrink-0" style={{ background: "linear-gradient(135deg,#9a6b1f,#e8c46a)", color: "#fff8e7" }}>
                  {m.photoUrl ? <img src={m.photoUrl} alt={m.name} className="w-full h-full object-cover rounded-2xl" /> : initials(m.name)}
                </div>
                <div className="min-w-0">
                  <h3 className="font-display font-bold text-[17px] leading-tight truncate">{m.name}</h3>
                  <span className="inline-flex mt-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-[0.12em] uppercase" style={{ background: "color-mix(in srgb, var(--gold-500) 16%, transparent)", color: "var(--gold-700)" }}>{m.role}</span>
                  <p className="mt-1.5 text-[12px] font-medium" style={{ color: "var(--ink-faint)" }}>{m.wing}</p>
                </div>
              </div>
              <p className="mt-4 text-[13px] leading-relaxed line-clamp-2" style={{ color: "var(--ink-soft)" }}>{m.bio}</p>
              <span className="mt-3 inline-flex items-center gap-1 text-[12px] font-semibold" style={{ color: "var(--gold-600)" }}>View profile <Icon d={I.arrowRight} size={13} /></span>
            </button>
          ))}
        </div>
      </div>
      {sel && (
        <div className="fixed inset-0 z-[100] grid place-items-center p-4" onClick={() => setSel(null)}>
          <div className="absolute inset-0" style={{ background: "rgba(40,28,10,.55)", backdropFilter: "blur(6px)" }} />
          <div className="relative card-cream max-w-md w-full p-7 modal-scroll max-h-[85vh] overflow-auto" style={{ background: "var(--card)" }} onClick={(e) => e.stopPropagation()}>
            <button onClick={() => setSel(null)} className="absolute top-4 right-4 w-8 h-8 grid place-items-center rounded-full border" style={{ borderColor: "var(--card-border)", color: "var(--ink-soft)" }}><Icon d={I.x} size={15} /></button>
            <div className="flex items-center gap-4">
              <div className="w-20 h-20 rounded-3xl grid place-items-center font-display font-bold text-[26px]" style={{ background: "linear-gradient(135deg,#9a6b1f,#e8c46a)", color: "#fff8e7" }}>
                {sel.photoUrl ? <img src={sel.photoUrl} alt={sel.name} className="w-full h-full object-cover rounded-3xl" /> : initials(sel.name)}
              </div>
              <div>
                <h3 className="font-display font-bold text-[22px]">{sel.name}</h3>
                <p className="text-[12px] font-bold tracking-[0.14em] uppercase" style={{ color: "var(--gold-600)" }}>{sel.role}</p>
                <p className="text-[12px]" style={{ color: "var(--ink-faint)" }}>{sel.wing}</p>
              </div>
            </div>
            <p className="mt-5 text-[14px] leading-relaxed" style={{ color: "var(--ink-soft)" }}>{sel.bio || "Serving the batch with sincerity."}</p>
            <div className="mt-5 flex gap-2">
              <button className="btn-gold flex-1" onClick={() => { try { navigator.clipboard.writeText(`${sel.name} — ${sel.role}, ${sel.wing} (Widad Friends)`); onToast("Profile copied"); } catch { onToast("Copy failed", "err"); } }}>Copy contact</button>
              <button className="btn-ghost" onClick={() => setSel(null)}>Close</button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

/* ---------- wings ---------- */
export function Wings({ wings, members }: { wings: Wing[]; members: CommitteeMember[] }) {
  const [sel, setSel] = useState<Wing | null>(null);
  const go = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  return (
    <section id="wings" className="section-pad scroll-mt-20" style={{ background: "color-mix(in srgb, var(--card) 38%, transparent)", borderTop: "1px solid var(--card-border)", borderBottom: "1px solid var(--card-border)" }}>
      <div className="max-w-6xl mx-auto px-5">
        <Heading eyebrow="Six paths, one bond" title="Explore the Wings" sub="Every member belongs to a wing — Da'wa, Arts and Discipline live through these six families." />
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {wings.map((w) => {
            const crew = members.filter((m) => m.wing === w.name);
            return (
              <div key={w.id} className="card-cream p-6 hover:-translate-y-1 transition-transform duration-300 flex flex-col">
                <div className="flex items-center justify-between">
                  <div className="w-11 h-11 rounded-2xl grid place-items-center" style={{ background: `color-mix(in srgb, ${w.color} 16%, transparent)`, color: w.color }}>
                    <Icon d={WING_ICON[w.icon] ?? I.sparkles} size={20} />
                  </div>
                  <span className="text-[11px] font-bold px-2.5 py-1 rounded-full border" style={{ borderColor: "var(--card-border)", color: "var(--ink-faint)" }}>{w.memberCount} members</span>
                </div>
                <h3 className="font-display font-bold text-[19px] mt-4">{w.name}</h3>
                <p className="text-[11px] font-bold tracking-[0.18em] uppercase mt-0.5" style={{ color: w.color }}>{w.tagline}</p>
                <p className="mt-3 text-[13px] leading-relaxed flex-1" style={{ color: "var(--ink-soft)" }}>{w.description}</p>
                <div className="mt-4 pt-4 flex items-center justify-between border-t" style={{ borderColor: "var(--card-border)" }}>
                  <div className="text-[12px]"><span style={{ color: "var(--ink-faint)" }}>Led by </span><strong>{w.leaderName}</strong>{crew.length > 0 && <span style={{ color: "var(--ink-faint)" }}> · +{crew.length} council</span>}</div>
                  <button onClick={() => setSel(w)} className="text-[12px] font-bold inline-flex items-center gap-1" style={{ color: "var(--gold-600)" }}>Details <Icon d={I.arrowRight} size={13} /></button>
                </div>
              </div>
            );
          })}
        </div>
        <div className="mt-8 card-cream px-6 py-5 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-[13px]" style={{ color: "var(--ink-soft)" }}><strong>Not in a wing yet?</strong> Registrations for 2026 are open — message the union chat and we&apos;ll place you.</p>
          <button className="btn-gold shrink-0" onClick={() => go("chat")}>Join via chat <Icon d={I.arrowRight} size={14} /></button>
        </div>
      </div>
      {sel && (
        <div className="fixed inset-0 z-[100] grid place-items-center p-4" onClick={() => setSel(null)}>
          <div className="absolute inset-0" style={{ background: "rgba(40,28,10,.55)", backdropFilter: "blur(6px)" }} />
          <div className="relative card-cream max-w-lg w-full p-7 max-h-[85vh] overflow-auto modal-scroll" style={{ background: "var(--card)" }} onClick={(e) => e.stopPropagation()}>
            <button onClick={() => setSel(null)} className="absolute top-4 right-4 w-8 h-8 grid place-items-center rounded-full border" style={{ borderColor: "var(--card-border)", color: "var(--ink-soft)" }}><Icon d={I.x} size={15} /></button>
            <div className="w-12 h-12 rounded-2xl grid place-items-center" style={{ background: `color-mix(in srgb, ${sel.color} 16%, transparent)`, color: sel.color }}>
              <Icon d={WING_ICON[sel.icon] ?? I.sparkles} size={22} />
            </div>
            <h3 className="font-display font-bold text-[26px] mt-3">{sel.name}</h3>
            <p className="text-[12px] font-bold tracking-[0.18em] uppercase" style={{ color: sel.color }}>{sel.tagline}</p>
            <p className="mt-4 text-[14px] leading-relaxed" style={{ color: "var(--ink-soft)" }}>{sel.description}</p>
            <div className="mt-5 grid grid-cols-2 gap-3">
              <div className="rounded-2xl border p-4" style={{ borderColor: "var(--card-border)" }}>
                <p className="text-[10px] font-bold tracking-[0.2em] uppercase" style={{ color: "var(--ink-faint)" }}>Wing leader</p>
                <p className="font-semibold text-[14px] mt-1">{sel.leaderName}</p>
              </div>
              <div className="rounded-2xl border p-4" style={{ borderColor: "var(--card-border)" }}>
                <p className="text-[10px] font-bold tracking-[0.2em] uppercase" style={{ color: "var(--ink-faint)" }}>Strength</p>
                <p className="font-semibold text-[14px] mt-1">{sel.memberCount} members</p>
              </div>
            </div>
            <button className="btn-gold w-full mt-5" onClick={() => { setSel(null); document.getElementById("chat")?.scrollIntoView({ behavior: "smooth" }); }}>Ask to join this wing</button>
          </div>
        </div>
      )}
    </section>
  );
}

/* ---------- gallery ---------- */
export function Gallery({ items, isAdmin, onChanged, onToast }: { items: GalleryItem[]; isAdmin: boolean; onChanged: () => void; onToast: (m: string, k?: "ok" | "err") => void }) {
  const [cat, setCat] = useState("All");
  const [light, setLight] = useState<number | null>(null);
  const cats = ["All", ...Array.from(new Set(items.map((g) => g.category)))];
  const list = cat === "All" ? items : items.filter((g) => g.category === cat);
  const del = async (id: string) => {
    if (!confirm("Delete this photo?")) return;
    const r = await fetch(`/api/gallery?id=${id}`, { method: "DELETE" });
    if (r.ok) { onToast("Photo deleted"); onChanged(); } else onToast("Delete failed", "err");
  };
  return (
    <section id="gallery" className="section-pad scroll-mt-20">
      <div className="max-w-6xl mx-auto px-5">
        <Heading eyebrow="Memories" title="Gallery" sub="Iftar nights, Arts Fest, Batch Cup and quiet halaqa evenings — the batch in frames." />
        <div className="flex gap-2 flex-wrap justify-center mb-7">
          {cats.map((c) => (
            <button key={c} onClick={() => setCat(c)} className="px-4 py-1.5 rounded-full text-[12px] font-bold border transition" style={cat === c ? { background: "var(--gold-600)", color: "#fff8e7", borderColor: "transparent" } : { borderColor: "var(--card-border)", color: "var(--ink-soft)", background: "var(--card)" }}>
              {c}
            </button>
          ))}
        </div>
        {list.length === 0 && <p className="text-center py-14 text-sm" style={{ color: "var(--ink-faint)" }}>No photos in this album yet.</p>}
        <div className="columns-2 md:columns-3 gap-4 [column-fill:_balance]">
          {list.map((g, i) => (
            <figure key={g.id} className="relative mb-4 break-inside-avoid rounded-2xl overflow-hidden group border cursor-zoom-in" style={{ borderColor: "var(--card-border)" }} onClick={() => setLight(i)}>
              <img src={g.imageUrl} alt={g.title} loading="lazy" className="w-full object-cover transition-transform duration-500 group-hover:scale-105" onError={(e) => { (e.target as HTMLImageElement).src = "https://picsum.photos/seed/" + g.id + "/800/600"; }} />
              <figcaption className="absolute inset-x-0 bottom-0 p-3 pt-8 text-left" style={{ background: "linear-gradient(to top, rgba(20,12,4,.78), transparent)" }}>
                <p className="text-white text-[13px] font-semibold leading-tight">{g.title}</p>
                <p className="text-[10px] font-bold tracking-[0.18em] uppercase text-amber-200/90">{g.category}</p>
              </figcaption>
              {isAdmin && (
                <button onClick={(e) => { e.stopPropagation(); del(g.id); }} className="absolute top-2 right-2 w-8 h-8 grid place-items-center rounded-full text-white opacity-0 group-hover:opacity-100 transition" style={{ background: "rgba(179,55,47,.9)" }} title="Delete">
                  <Icon d={I.trash} size={14} />
                </button>
              )}
            </figure>
          ))}
        </div>
      </div>
      {light !== null && list[light] && (
        <div className="fixed inset-0 z-[100] grid place-items-center p-4" onClick={() => setLight(null)}>
          <div className="absolute inset-0 bg-black/85" style={{ backdropFilter: "blur(6px)" }} />
          <div className="relative max-w-3xl w-full" onClick={(e) => e.stopPropagation()}>
            <img src={list[light].imageUrl} alt={list[light].title} className="w-full max-h-[75vh] object-contain rounded-2xl" />
            <div className="mt-3 flex items-center justify-between text-white">
              <div><p className="font-semibold text-[15px]">{list[light].title}</p><p className="text-[11px] tracking-[0.2em] uppercase text-white/60">{list[light].category} · {light + 1} / {list.length}</p></div>
              <div className="flex gap-2">
                <button onClick={() => setLight((light - 1 + list.length) % list.length)} className="px-4 py-2 rounded-full bg-white/10 hover:bg-white/20 text-sm font-bold">‹ Prev</button>
                <button onClick={() => setLight((light + 1) % list.length)} className="px-4 py-2 rounded-full bg-white/10 hover:bg-white/20 text-sm font-bold">Next ›</button>
                <button onClick={() => setLight(null)} className="w-10 h-10 grid place-items-center rounded-full bg-white/10 hover:bg-white/20"><Icon d={I.x} size={16} /></button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

/* ---------- news ---------- */
export function News({ posts, isAdmin, onChanged, onToast }: { posts: NewsPost[]; isAdmin: boolean; onChanged: () => void; onToast: (m: string, k?: "ok" | "err") => void }) {
  const [q, setQ] = useState("");
  const [sel, setSel] = useState<NewsPost | null>(null);
  const list = useMemo(() => {
    const s = q.toLowerCase();
    return [...posts].sort((a, b) => Number(b.pinned) - Number(a.pinned) || +new Date(b.publishedAt ?? 0) - +new Date(a.publishedAt ?? 0)).filter((p) => !s || p.title.toLowerCase().includes(s) || p.excerpt.toLowerCase().includes(s));
  }, [posts, q]);
  const featured = list.find((p) => p.pinned) ?? list[0];
  const rest = featured ? list.filter((p) => p.id !== featured.id) : [];
  const del = async (id: string) => {
    if (!confirm("Delete this post?")) return;
    const r = await fetch(`/api/news?id=${id}`, { method: "DELETE" });
    if (r.ok) { onToast("Post deleted"); onChanged(); } else onToast("Delete failed", "err");
  };
  return (
    <section id="news" className="section-pad scroll-mt-20" style={{ background: "color-mix(in srgb, var(--card) 38%, transparent)", borderTop: "1px solid var(--card-border)", borderBottom: "1px solid var(--card-border)" }}>
      <div className="max-w-6xl mx-auto px-5">
        <Heading eyebrow="Announcements" title="News & Events" sub="Official announcements from the council and wings — newest first." />
        <div className="relative max-w-md mx-auto mb-8">
          <span className="absolute left-3.5 top-1/2 -translate-y-1/2" style={{ color: "var(--ink-faint)" }}><Icon d={I.search} size={16} /></span>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search announcements…" className="field pl-10" />
        </div>
        {featured && (
          <article className="card-cream overflow-hidden grid md:grid-cols-2 cursor-pointer hover:-translate-y-1 transition-transform duration-300" onClick={() => setSel(featured)}>
            <div className="relative min-h-[240px]">
              <img src={featured.imageUrl} alt="" className="absolute inset-0 w-full h-full object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
              {!featured.imageUrl && <div className="absolute inset-0 grid place-items-center font-display text-5xl gold-text font-bold">W</div>}
              {featured.pinned && <span className="absolute top-4 left-4 inline-flex items-center gap-1 px-3 py-1 rounded-full text-[10px] font-bold tracking-[0.16em] uppercase text-white" style={{ background: "var(--gold-600)" }}><Icon d={I.pin} size={11} /> Pinned</span>}
            </div>
            <div className="p-7 md:p-9">
              <p className="text-[11px] font-bold tracking-[0.2em] uppercase" style={{ color: "var(--ink-faint)" }}>{timeAgo(featured.publishedAt ?? new Date())} · {featured.author}</p>
              <h3 className="font-display font-bold text-[24px] md:text-[28px] leading-tight mt-2">{featured.title}</h3>
              <p className="mt-3 text-[14px] leading-relaxed" style={{ color: "var(--ink-soft)" }}>{featured.excerpt}</p>
              <span className="mt-4 inline-flex items-center gap-1.5 text-[13px] font-bold" style={{ color: "var(--gold-600)" }}>Read full story <Icon d={I.arrowRight} size={14} /></span>
            </div>
          </article>
        )}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 mt-6">
          {rest.map((p) => (
            <article key={p.id} className="card-cream overflow-hidden group cursor-pointer hover:-translate-y-1 transition-transform duration-300" onClick={() => setSel(p)}>
              <div className="relative h-44 overflow-hidden" style={{ background: "color-mix(in srgb, var(--gold-500) 12%, var(--card))" }}>
                {p.imageUrl ? <img src={p.imageUrl} alt="" loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} /> : <div className="w-full h-full grid place-items-center font-display text-4xl gold-text font-bold">W</div>}
                {isAdmin && (
                  <button onClick={(e) => { e.stopPropagation(); del(p.id); }} className="absolute top-2 right-2 w-8 h-8 grid place-items-center rounded-full text-white" style={{ background: "rgba(179,55,47,.9)" }}><Icon d={I.trash} size={14} /></button>
                )}
              </div>
              <div className="p-5">
                <p className="text-[10px] font-bold tracking-[0.2em] uppercase" style={{ color: "var(--ink-faint)" }}>{timeAgo(p.publishedAt ?? new Date())} · {p.author}</p>
                <h4 className="font-display font-bold text-[16px] leading-snug mt-1.5 line-clamp-2">{p.title}</h4>
                <p className="text-[13px] mt-2 line-clamp-2" style={{ color: "var(--ink-soft)" }}>{p.excerpt}</p>
              </div>
            </article>
          ))}
        </div>
        {list.length === 0 && <p className="text-center py-14 text-sm" style={{ color: "var(--ink-faint)" }}>No announcements found.</p>}
      </div>
      {sel && (
        <div className="fixed inset-0 z-[100] grid place-items-center p-4" onClick={() => setSel(null)}>
          <div className="absolute inset-0" style={{ background: "rgba(40,28,10,.55)", backdropFilter: "blur(6px)" }} />
          <div className="relative card-cream max-w-2xl w-full max-h-[85vh] overflow-auto modal-scroll" style={{ background: "var(--card)" }} onClick={(e) => e.stopPropagation()}>
            {sel.imageUrl && <img src={sel.imageUrl} alt="" className="w-full h-60 object-cover" />}
            <div className="p-7">
              <button onClick={() => setSel(null)} className="absolute top-4 right-4 w-8 h-8 grid place-items-center rounded-full border bg-[var(--card)]" style={{ borderColor: "var(--card-border)", color: "var(--ink-soft)" }}><Icon d={I.x} size={15} /></button>
              <p className="text-[11px] font-bold tracking-[0.2em] uppercase" style={{ color: "var(--ink-faint)" }}>{new Date(sel.publishedAt ?? Date.now()).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })} · {sel.author}</p>
              <h3 className="font-display font-bold text-[26px] leading-tight mt-2">{sel.title}</h3>
              <div className="mt-4 text-[14.5px] leading-[1.8] whitespace-pre-line" style={{ color: "var(--ink-soft)" }}>{sel.content || sel.excerpt}</div>
              <button className="btn-ghost w-full mt-6" onClick={() => setSel(null)}>Close</button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
