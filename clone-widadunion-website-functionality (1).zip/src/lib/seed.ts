import { db } from "@/db";
import { committeeMembers, wings, galleryItems, newsPosts, chatMessages } from "@/db/schema";
import { sql } from "drizzle-orm";

export async function ensureSeeded() {
  try {
    const existing = await db.execute(sql`select count(*)::int as c from ${wings}`);
    const count = Number(((existing.rows[0] ?? {}) as Record<string, unknown>).c ?? 0);
    if (count > 0) return { seeded: false };
  } catch {
    return { seeded: false, error: "tables-missing" };
  }

  const wingSeed = [
    { name: "Da'wah Wing", slug: "dawah", tagline: "Call with wisdom", description: "Qur'an halaqas, Fajr reminders, Friday khutbah rota, new-student da'wah mentoring and charity da'wah stalls across campus.", icon: "moon", leaderName: "Mohamed Aiman", memberCount: 24, color: "#8A5A1B" },
    { name: "Arts & Culture Wing", slug: "arts", tagline: "Beauty with purpose", description: "Nasheed nights, calligraphy, spoken word, drama and the annual Widad Arts Fest — creativity anchored in adab.", icon: "sparkles", leaderName: "Aishath Sara", memberCount: 31, color: "#B07C2A" },
    { name: "Discipline Wing", slug: "discipline", tagline: "Adab before ilm", description: "Attendance, dress code, hostel manners and event marshalling. The quiet backbone that keeps the batch dignified.", icon: "shield", leaderName: "Ahmed Zayan", memberCount: 18, color: "#6B4A1E" },
    { name: "Media & Design Wing", slug: "media", tagline: "Stories that shine", description: "Photography, posters, reels, the union site and newsletter. Every memory you see here passed through this wing.", icon: "camera", leaderName: "Fathimath Naja", memberCount: 22, color: "#C49A3F" },
    { name: "Sports Wing", slug: "sports", tagline: "Strong body, strong bond", description: "Football, futsal, badminton and inter-batch tournaments. Weekly fixtures plus the legendary Batch Cup.", icon: "trophy", leaderName: "Hussain Rilwan", memberCount: 27, color: "#9A6B1F" },
    { name: "Academic Wing", slug: "academic", tagline: "Excel together", description: "Study circles, past-paper banks, peer tutoring and exam-season support. Nobody in Class 2 studies alone.", icon: "book", leaderName: "Mariyam Laya", memberCount: 29, color: "#7A5C22" },
  ];

  const committeeSeed = [
    { name: "Mohamed Widad", role: "President", wing: "General", bio: "Leads the union vision, chairs council meetings and represents Class 2 in all batch affairs.", photoUrl: "", displayOrder: 1 },
    { name: "Aishath Hana", role: "Vice President", wing: "General", bio: "Coordinates wings, steps in for the president and keeps every project on schedule.", photoUrl: "", displayOrder: 2 },
    { name: "Ahmed Shafiu", role: "General Secretary", wing: "General", bio: "Minutes, records, official letters and the union calendar — the memory of the batch.", photoUrl: "", displayOrder: 3 },
    { name: "Fathimath Zaha", role: "Treasurer", wing: "General", bio: "Guards the amanah of funds, publishes monthly accounts and budgets every event.", photoUrl: "", displayOrder: 4 },
    { name: "Mohamed Aiman", role: "Da'wah Head", wing: "Da'wah Wing", bio: "Runs halaqas, Fajr campaign and Friday programmes for the batch.", photoUrl: "", displayOrder: 5 },
    { name: "Aishath Sara", role: "Arts Head", wing: "Arts & Culture Wing", bio: "Directs Arts Fest, nasheed crew and the culture calendar.", photoUrl: "", displayOrder: 6 },
    { name: "Ahmed Zayan", role: "Discipline Head", wing: "Discipline Wing", bio: "Heads the marshall team and upholds the union code of conduct.", photoUrl: "", displayOrder: 7 },
    { name: "Fathimath Naja", role: "Media Head", wing: "Media & Design Wing", bio: "Leads photography, design and this very website.", photoUrl: "", displayOrder: 8 },
    { name: "Hussain Rilwan", role: "Sports Head", wing: "Sports Wing", bio: "Organises fixtures, the Batch Cup and weekly training.", photoUrl: "", displayOrder: 9 },
  ];

  const gallerySeed = [
    { title: "Batch iftar gathering", imageUrl: "https://picsum.photos/seed/widad-iftar/800/600", category: "Events" },
    { title: "Arts fest stage night", imageUrl: "https://picsum.photos/seed/widad-arts/800/600", category: "Arts" },
    { title: "Friday halaqa circle", imageUrl: "https://picsum.photos/seed/widad-halaqa/800/600", category: "Da'wah" },
    { title: "Batch Cup final", imageUrl: "https://picsum.photos/seed/widad-cup/800/600", category: "Sports" },
    { title: "Calligraphy workshop", imageUrl: "https://picsum.photos/seed/widad-calli/800/600", category: "Arts" },
    { title: "Charity food drive", imageUrl: "https://picsum.photos/seed/widad-charity/800/600", category: "Da'wah" },
    { title: "Study circle week", imageUrl: "https://picsum.photos/seed/widad-study/800/600", category: "Academic" },
    { title: "Union council 2026", imageUrl: "https://picsum.photos/seed/widad-council/800/600", category: "Events" },
  ];

  const now = new Date();
  const daysAgo = (n: number) => new Date(now.getTime() - n * 86400000);
  const newsSeed = [
    { title: "Widad Friends union officially launched", excerpt: "Class 2 of the 23rd Batch inaugurates its union under the motto Worthy Individuals for Da'wa, Arts and Discipline.", content: "Alhamdulillah, the Class 2 Union — WIDAD FRIENDS — of the 23rd Batch (BUAC Maniyyor) has been officially launched.\n\nThe launch gathered the full batch, mentors and guests. The new council took oath to serve with amanah, adab and unity.\n\nWIDAD stands for Worthy Individuals for Da'wa, Arts and Discipline — three pillars every wing will carry this year.\n\nUpcoming: wing registrations open this week, followed by the orientation night and the first halaqa.", imageUrl: "https://picsum.photos/seed/widad-news1/900/500", author: "Union Media", pinned: true, publishedAt: daysAgo(2) },
    { title: "Wing registrations open — pick your path", excerpt: "Six wings open intake: Da'wah, Arts, Discipline, Media, Sports and Academic. Slots are limited per wing.", content: "All six wings have opened registration for the 2026 term.\n\n• Da'wah Wing — halaqa & mentoring\n• Arts & Culture — nasheed, drama, calligraphy\n• Discipline — marshall & conduct\n• Media & Design — photo, design, web\n• Sports — football, badminton, Batch Cup\n• Academic — tutoring & study circles\n\nRegister through any committee member or the chat below. Orientation for new wing members is on Friday after Maghrib.", imageUrl: "https://picsum.photos/seed/widad-news2/900/500", author: "General Secretary", pinned: false, publishedAt: daysAgo(5) },
    { title: "Batch Cup fixtures announced", excerpt: "The inter-class football tournament kicks off next week. Class 2 fields two squads.", content: "The Sports Wing has released the Batch Cup fixtures.\n\nClass 2 enters two squads — Widad A and Widad B. Training is every evening at the campus ground.\n\nSupporters bring the energy: drums, banners and the famous batch chant. Full fixture list is pinned in the gallery notice board.\n\nMay the best manners win, on and off the pitch.", imageUrl: "https://picsum.photos/seed/widad-news3/900/500", author: "Sports Wing", pinned: false, publishedAt: daysAgo(9) },
    { title: "Charity food drive feeds 200 families", excerpt: "Da'wah Wing and volunteers packed and delivered food parcels across the neighbourhood.", content: "Jazakumullah to every volunteer who joined the charity food drive.\n\nOver 200 food parcels were packed at the union room and delivered across the neighbourhood in one evening.\n\nThe Discipline Wing managed logistics, Media covered the story, and Arts made the thank-you cards for donors.\n\nThis is WIDAD in action — da'wa through service.", imageUrl: "https://picsum.photos/seed/widad-news4/900/500", author: "Da'wah Wing", pinned: false, publishedAt: daysAgo(14) },
  ];

  const chatSeed = [
    { displayName: "Union Bot", message: "Assalamu alaikum! Welcome to the Widad Friends union chat. Be kind, no spam. Committee announcements appear in News." },
    { displayName: "Aiman", message: "Halaqa tonight after Isha in the union room in sha Allah. All brothers welcome." },
    { displayName: "Sara", message: "Arts wing audition for nasheed crew is Friday! DM me to register 🎶" },
  ];

  await db.insert(wings).values(wingSeed);
  await db.insert(committeeMembers).values(committeeSeed);
  await db.insert(galleryItems).values(gallerySeed);
  await db.insert(newsPosts).values(newsSeed);
  await db.insert(chatMessages).values(chatSeed.map((c) => ({ ...c })));
  return { seeded: true };
}
