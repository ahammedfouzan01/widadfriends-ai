"use client";

import { useEffect, useRef, useState } from "react";
import { Heading, Icon, I, WidadMark } from "./chrome";
import { initials, timeAgo } from "./sections";
import type { ChatMessage, CommitteeMember, Wing, GalleryItem, NewsPost } from "@/db/schema";

/* ================= CHAT ================= */
export function Chat({ isAdmin, onToast, onCount }: { isAdmin: boolean; onToast: (m: string, k?: "ok" | "err") => void; onCount: () => void }) {
  const [msgs, setMsgs] = useState<ChatMessage[]>([]);
  const [name, setName] = useState("");
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const boxRef = useRef<HTMLDivElement>(null);
  const [stick, setStick] = useState(true);

  const load = async (silent = true) => {
    try {
      const r = await fetch("/api/chat", { cache: "no-store" });
      if (r.ok) {
        const j = await r.json();
        setMsgs(j.messages ?? []);
        if (stick) requestAnimationFrame(() => boxRef.current?.scrollTo({ top: 99999 }));
      }
    } catch { if (!silent) onToast("Chat offline", "err"); }
  };
  useEffect(() => {
    try { setName(localStorage.getItem("widad-name") ?? ""); } catch {}
    load(false);
    const t = setInterval(() => load(true), 3500);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const send = async () => {
    const n = name.trim().slice(0, 30);
    const m = text.trim().slice(0, 500);
    if (!n) return onToast("Enter your name first", "err");
    if (!m) return;
    setSending(true);
    try {
      try { localStorage.setItem("widad-name", n); } catch {}
      const r = await fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ displayName: n, message: m }) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) return onToast(j.error ?? "Could not send", "err");
      setText("");
      setStick(true);
      await load(true);
      onCount();
    } finally { setSending(false); }
  };

  const del = async (id: string) => {
    if (!confirm("Delete message?")) return;
    const r = await fetch(`/api/chat?id=${id}`, { method: "DELETE" });
    if (r.ok) { load(true); onToast("Message deleted"); } else onToast("Delete failed", "err");
  };

  return (
    <section id="chat" className="section-pad scroll-mt-20">
      <div className="max-w-3xl mx-auto px-5">
        <Heading eyebrow="Live discussion" title="Union Chat" sub="The batch majlis, online — announcements, questions, lost & found. Keep it clean." />
        <div className="card-cream overflow-hidden">
          <div className="px-5 py-3.5 flex items-center justify-between border-b" style={{ borderColor: "var(--card-border)" }}>
            <div className="flex items-center gap-2 text-[12px] font-bold">
              <span className="w-2 h-2 rounded-full bg-green-600 animate-pulse" /> {msgs.length} messages · live every 3s
            </div>
            <span className="text-[11px] font-semibold" style={{ color: "var(--ink-faint)" }}>No spam · No abuse</span>
          </div>
          <div ref={boxRef} onScroll={(e) => { const el = e.currentTarget; setStick(el.scrollHeight - el.scrollTop - el.clientHeight < 90); }} className="chat-scroll h-[380px] overflow-y-auto px-4 py-4 flex flex-col gap-3" style={{ background: "color-mix(in srgb, var(--bg) 40%, transparent)" }}>
            {msgs.map((m) => {
              const mine = m.displayName === name && name !== "";
              const bot = m.displayName.toLowerCase().includes("bot");
              return (
                <div key={m.id} className={`flex gap-2.5 group ${mine ? "flex-row-reverse" : ""}`}>
                  <div className="w-8 h-8 rounded-full grid place-items-center text-[11px] font-bold shrink-0" style={{ background: bot ? "var(--gold-600)" : mine ? "linear-gradient(135deg,#9a6b1f,#e8c46a)" : "color-mix(in srgb, var(--gold-500) 25%, var(--card))", color: bot || mine ? "#fff8e7" : "var(--gold-700)" }}>
                    {initials(m.displayName)}
                  </div>
                  <div className={`max-w-[78%] rounded-2xl px-3.5 py-2.5 border ${mine ? "rounded-tr-md" : "rounded-tl-md"}`} style={{ background: "var(--card)", borderColor: "var(--card-border)" }}>
                    <div className="flex items-baseline gap-2">
                      <span className="text-[11px] font-bold" style={{ color: "var(--gold-700)" }}>{m.displayName}</span>
                      <span className="text-[10px]" style={{ color: "var(--ink-faint)" }}>{timeAgo(m.createdAt ?? new Date())}</span>
                      {isAdmin && <button onClick={() => del(m.id)} className="ml-auto opacity-0 group-hover:opacity-100 transition text-[10px] font-bold" style={{ color: "#b3372f" }}>delete</button>}
                    </div>
                    <p className="text-[13.5px] leading-relaxed mt-0.5 whitespace-pre-wrap break-words" style={{ color: "var(--ink)" }}>{m.message}</p>
                  </div>
                </div>
              );
            })}
            {msgs.length === 0 && <p className="text-center text-[13px] py-16" style={{ color: "var(--ink-faint)" }}>No messages yet — start the conversation.</p>}
          </div>
          <div className="p-4 border-t" style={{ borderColor: "var(--card-border)", background: "var(--card)" }}>
            <div className="flex gap-2 mb-2">
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name…" maxLength={30} className="field !w-40" />
              <input value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()} placeholder="Write a message… (Enter to send)" maxLength={500} className="field flex-1" />
              <button onClick={send} disabled={sending} className="btn-gold !px-4 shrink-0" aria-label="Send">
                <Icon d={I.send} size={16} /> <span className="hidden sm:inline">{sending ? "…" : "Send"}</span>
              </button>
            </div>
            <p className="text-[11px]" style={{ color: "var(--ink-faint)" }}>{500 - text.length} characters left · be respectful, messages are public to the batch</p>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ================= FOOTER ================= */
export function Footer() {
  const go = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  return (
    <footer className="border-t mt-4" style={{ borderColor: "var(--card-border)", background: "color-mix(in srgb, var(--card) 55%, transparent)" }}>
      <div className="max-w-6xl mx-auto px-5 py-12 grid md:grid-cols-3 gap-10">
        <div>
          <div className="flex items-center gap-2.5">
            <WidadMark size={30} />
            <span className="font-display text-[20px] font-semibold lowercase" style={{ color: "var(--gold-600)" }}>widad</span>
          </div>
          <p className="mt-3 text-[13px] leading-relaxed max-w-xs" style={{ color: "var(--ink-soft)" }}>Widad Friends — Class 2 Union of the 23rd Batch. Worthy Individuals for Da&apos;wa, Arts and Discipline.</p>
          <p className="mt-3 text-[11px] font-bold tracking-[0.2em] uppercase" style={{ color: "var(--ink-faint)" }}>BUAC Maniyyor · 2026</p>
        </div>
        <div>
          <p className="eyebrow mb-4">Explore</p>
          <div className="grid grid-cols-2 gap-2">
            {[["committee", "Committee"], ["wings", "Wings"], ["gallery", "Gallery"], ["news", "News"], ["chat", "Chat"], ["home", "Top"]].map(([id, l]) => (
              <button key={id} onClick={() => go(id)} className="text-left text-[13px] font-medium hover:underline" style={{ color: "var(--ink-soft)" }}>{l}</button>
            ))}
          </div>
        </div>
        <div>
          <p className="eyebrow mb-4">Union motto</p>
          <p className="font-display text-[22px] leading-snug gold-text font-bold">Da&apos;wa with wisdom,<br />Arts with adab,<br />Discipline with love.</p>
          <p className="mt-4 text-[12px]" style={{ color: "var(--ink-faint)" }}>© 2026 Widad Friends · Class 2 Union · Built with sincerity for the batch.</p>
        </div>
      </div>
    </footer>
  );
}

/* ================= ADMIN ================= */
type Tab = "overview" | "committee" | "wings" | "gallery" | "news";

export function AdminPanel({ open, onClose, data, onChanged, onToast }: {
  open: boolean;
  onClose: () => void;
  data: { committee: CommitteeMember[]; wings: Wing[]; gallery: GalleryItem[]; news: NewsPost[]; chat: number };
  onChanged: () => void;
  onToast: (m: string, k?: "ok" | "err") => void;
}) {
  const [tab, setTab] = useState<Tab>("overview");
  const [authed, setAuthed] = useState(false);
  const [pw, setPw] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (open) { try { setAuthed(sessionStorage.getItem("widad-admin") === "1"); } catch {} }
  }, [open ]);
  if (!open) return null;

  const login = async () => {
    setBusy(true);
    try {
      const r = await fetch("/api/site", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "login", password: pw }) });
      const j = await r.json();
      if (j.ok) { setAuthed(true); try { sessionStorage.setItem("widad-admin", "1"); } catch {} onToast("Welcome back, admin"); }
      else onToast("Wrong password", "err");
    } finally { setBusy(false); }
  };
  const logout = () => { setAuthed(false); try { sessionStorage.removeItem("widad-admin"); } catch {} onClose(); };

  return (
    <div className="fixed inset-0 z-[110] grid place-items-center p-3 sm:p-6" onClick={onClose}>
      <div className="absolute inset-0" style={{ background: "rgba(30,20,6,.6)", backdropFilter: "blur(8px)" }} />
      <div className="relative w-full max-w-4xl max-h-[90vh] overflow-hidden rounded-3xl border flex flex-col" style={{ background: "var(--card)", borderColor: "var(--card-border)" }} onClick={(e) => e.stopPropagation()}>
        <div className="px-6 py-4 flex items-center justify-between border-b shrink-0" style={{ borderColor: "var(--card-border)", background: "linear-gradient(135deg, color-mix(in srgb, var(--gold-600) 14%, var(--card)), var(--card))" }}>
          <div className="flex items-center gap-2.5">
            <span className="w-9 h-9 grid place-items-center rounded-xl text-[#fff8e7]" style={{ background: "var(--gold-600)" }}><Icon d={I.lock} size={16} /></span>
            <div><p className="font-display font-bold text-[17px]">Admin Dashboard</p><p className="text-[11px]" style={{ color: "var(--ink-faint)" }}>Manage the union site — committee, wings, gallery, news</p></div>
          </div>
          <div className="flex items-center gap-2">
            {authed && <button onClick={logout} className="text-[11px] font-bold px-3 py-1.5 rounded-full border" style={{ borderColor: "var(--card-border)", color: "var(--ink-soft)" }}>Logout</button>}
            <button onClick={onClose} className="w-9 h-9 grid place-items-center rounded-full border" style={{ borderColor: "var(--card-border)", color: "var(--ink-soft)" }}><Icon d={I.x} size={16} /></button>
          </div>
        </div>

        {!authed ? (
          <div className="p-8 max-w-sm mx-auto w-full text-center">
            <WidadMark size={44} />
            <h3 className="font-display font-bold text-[22px] mt-3">Union Admin</h3>
            <p className="text-[13px] mt-1" style={{ color: "var(--ink-soft)" }}>Enter the council password to manage content. (Default: <code className="px-1.5 py-0.5 rounded" style={{ background: "color-mix(in srgb, var(--gold-500) 15%, transparent)" }}>widad2026</code>)</p>
            <input type="password" value={pw} onChange={(e) => setPw(e.target.value)} onKeyDown={(e) => e.key === "Enter" && login()} placeholder="Admin password" className="field mt-5 text-center" />
            <button onClick={login} disabled={busy} className="btn-gold w-full mt-3">{busy ? "Checking…" : "Unlock dashboard"}</button>
          </div>
        ) : (
          <>
            <div className="flex gap-1.5 px-4 pt-4 shrink-0 flex-wrap">
              {(["overview", "committee", "wings", "gallery", "news"] as Tab[]).map((t) => (
                <button key={t} onClick={() => setTab(t)} className="px-4 py-2 rounded-full text-[12px] font-bold capitalize border" style={tab === t ? { background: "var(--gold-600)", color: "#fff8e7", borderColor: "transparent" } : { borderColor: "var(--card-border)", color: "var(--ink-soft)" }}>{t}</button>
              ))}
            </div>
            <div className="p-5 overflow-y-auto modal-scroll grow">
              {tab === "overview" && <Overview data={data} onChanged={onChanged} onToast={onToast} />}
              {tab === "committee" && <CommitteeForm items={data.committee} onChanged={onChanged} onToast={onToast} />}
              {tab === "wings" && <WingsForm items={data.wings} onChanged={onChanged} onToast={onToast} />}
              {tab === "gallery" && <GalleryForm items={data.gallery} onChanged={onChanged} onToast={onToast} />}
              {tab === "news" && <NewsForm items={data.news} onChanged={onChanged} onToast={onToast} />}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function Overview({ data, onChanged, onToast }: { data: { committee: CommitteeMember[]; wings: Wing[]; gallery: GalleryItem[]; news: NewsPost[]; chat: number }; onChanged: () => void; onToast: (m: string, k?: "ok" | "err") => void }) {
  const reseed = async () => {
    if (!confirm("Reset all content to the original union demo data?")) return;
    const r = await fetch("/api/site", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "reseed" }) });
    if (r.ok) { onToast("Site reset to demo data"); onChanged(); } else onToast("Reset failed", "err");
  };
  const cards = [
    ["Committee", data.committee.length, I.users],
    ["Wings", data.wings.length, I.sparkles],
    ["Gallery", data.gallery.length, I.image],
    ["News", data.news.length, I.news],
    ["Chat msgs", data.chat, I.chat],
  ];
  return (
    <div>
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        {cards.map(([l, v, ic]) => (
          <div key={l as string} className="rounded-2xl border p-4 text-center" style={{ borderColor: "var(--card-border)" }}>
            <div className="mx-auto w-fit" style={{ color: "var(--gold-600)" }}><Icon d={ic as string} size={18} /></div>
            <p className="font-display font-bold text-[24px] mt-1">{v as number}</p>
            <p className="text-[10px] font-bold tracking-[0.18em] uppercase" style={{ color: "var(--ink-faint)" }}>{l as string}</p>
          </div>
        ))}
      </div>
      <div className="mt-5 rounded-2xl border p-5" style={{ borderColor: "var(--card-border)" }}>
        <p className="font-bold text-[14px]">Quick guide</p>
        <ul className="mt-2 text-[13px] space-y-1.5" style={{ color: "var(--ink-soft)" }}>
          <li>· Add committee members — they appear instantly on the home page with search & filters.</li>
          <li>· Wings drive the stats and the &quot;Explore wings&quot; cards.</li>
          <li>· Gallery accepts any image URL (upload to a host, paste here) — picsum seeds work great.</li>
          <li>· Pin one news post to feature it large at the top.</li>
          <li>· Chat deletes are instant for everyone (polls every 3s).</li>
        </ul>
        <button onClick={reseed} className="btn-ghost mt-4 !text-[12px]">Reset demo data</button>
      </div>
    </div>
  );
}

/* ----- generic row helpers ----- */
function Row({ children }: { children: React.ReactNode }) {
  return <div className="rounded-2xl border p-4" style={{ borderColor: "var(--card-border)" }}>{children}</div>;
}

function CommitteeForm({ items, onChanged, onToast }: { items: CommitteeMember[]; onChanged: () => void; onToast: (m: string, k?: "ok" | "err") => void }) {
  const empty = { name: "", role: "", wing: "General", bio: "", photoUrl: "", displayOrder: items.length + 1 };
  const [f, setF] = useState(empty);
  const [editId, setEditId] = useState<string | null>(null);
  const save = async () => {
    if (!f.name.trim() || !f.role.trim()) return onToast("Name and role required", "err");
    const method = editId ? "PUT" : "POST";
    const url = editId ? `/api/committee?id=${editId}` : "/api/committee";
    const r = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...f, displayOrder: Number(f.displayOrder) || 0 }) });
    if (r.ok) { onToast(editId ? "Member updated" : "Member added"); setF(empty); setEditId(null); onChanged(); } else onToast("Save failed", "err");
  };
  const del = async (id: string) => {
    if (!confirm("Remove this member?")) return;
    const r = await fetch(`/api/committee?id=${id}`, { method: "DELETE" });
    if (r.ok) { onToast("Member removed"); onChanged(); } else onToast("Delete failed", "err");
  };
  return (
    <div className="space-y-3">
      <Row>
        <p className="font-bold text-[13px] mb-3">{editId ? "Edit member" : "Add member"}</p>
        <div className="grid sm:grid-cols-2 gap-2">
          <input className="field" placeholder="Full name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
          <input className="field" placeholder="Role (e.g. President)" value={f.role} onChange={(e) => setF({ ...f, role: e.target.value })} />
          <input className="field" placeholder="Wing" value={f.wing} onChange={(e) => setF({ ...f, wing: e.target.value })} />
          <input className="field" placeholder="Photo URL (optional)" value={f.photoUrl} onChange={(e) => setF({ ...f, photoUrl: e.target.value })} />
          <input className="field sm:col-span-2" placeholder="Short bio" value={f.bio} onChange={(e) => setF({ ...f, bio: e.target.value })} />
          <input className="field" type="number" placeholder="Order" value={f.displayOrder} onChange={(e) => setF({ ...f, displayOrder: Number(e.target.value) })} />
          <div className="flex gap-2">
            <button onClick={save} className="btn-gold flex-1 !py-2.5">{editId ? "Update" : "Add member"}</button>
            {editId && <button onClick={() => { setEditId(null); setF(empty); }} className="btn-ghost !py-2.5">Cancel</button>}
          </div>
        </div>
      </Row>
      {items.map((m) => (
        <Row key={m.id}>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl grid place-items-center text-[13px] font-bold text-[#fff8e7] shrink-0" style={{ background: "linear-gradient(135deg,#9a6b1f,#e8c46a)" }}>{initials(m.name)}</div>
            <div className="min-w-0 flex-1"><p className="font-bold text-[13.5px] truncate">{m.name} <span className="font-medium" style={{ color: "var(--ink-faint)" }}>· {m.role}</span></p><p className="text-[11px]" style={{ color: "var(--ink-faint)" }}>{m.wing} · order {m.displayOrder}</p></div>
            <button onClick={() => { setEditId(m.id); setF({ name: m.name, role: m.role, wing: m.wing, bio: m.bio, photoUrl: m.photoUrl, displayOrder: m.displayOrder }); }} className="w-8 h-8 grid place-items-center rounded-full border" style={{ borderColor: "var(--card-border)", color: "var(--ink-soft)" }}><Icon d={I.edit} size={14} /></button>
            <button onClick={() => del(m.id)} className="w-8 h-8 grid place-items-center rounded-full" style={{ background: "rgba(179,55,47,.12)", color: "#b3372f" }}><Icon d={I.trash} size={14} /></button>
          </div>
        </Row>
      ))}
    </div>
  );
}

function WingsForm({ items, onChanged, onToast }: { items: Wing[]; onChanged: () => void; onToast: (m: string, k?: "ok" | "err") => void }) {
  const empty = { name: "", tagline: "", description: "", icon: "sparkles", leaderName: "", memberCount: 10, color: "#B07C2A" };
  const [f, setF] = useState(empty);
  const [editId, setEditId] = useState<string | null>(null);
  const save = async () => {
    if (!f.name.trim()) return onToast("Wing name required", "err");
    const method = editId ? "PUT" : "POST";
    const url = editId ? `/api/wings?id=${editId}` : "/api/wings";
    const r = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...f, memberCount: Number(f.memberCount) || 0, slug: f.name.toLowerCase().replace(/[^a-z0-9]+/g, "-") }) });
    if (r.ok) { onToast(editId ? "Wing updated" : "Wing added"); setF(empty); setEditId(null); onChanged(); } else onToast("Save failed", "err");
  };
  const del = async (id: string) => {
    if (!confirm("Delete this wing?")) return;
    const r = await fetch(`/api/wings?id=${id}`, { method: "DELETE" });
    if (r.ok) { onToast("Wing deleted"); onChanged(); } else onToast("Delete failed", "err");
  };
  return (
    <div className="space-y-3">
      <Row>
        <p className="font-bold text-[13px] mb-3">{editId ? "Edit wing" : "Add wing"}</p>
        <div className="grid sm:grid-cols-2 gap-2">
          <input className="field" placeholder="Wing name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
          <input className="field" placeholder="Tagline" value={f.tagline} onChange={(e) => setF({ ...f, tagline: e.target.value })} />
          <input className="field sm:col-span-2" placeholder="Description" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} />
          <input className="field" placeholder="Leader name" value={f.leaderName} onChange={(e) => setF({ ...f, leaderName: e.target.value })} />
          <div className="flex gap-2">
            <input className="field" type="number" placeholder="Members" value={f.memberCount} onChange={(e) => setF({ ...f, memberCount: Number(e.target.value) })} />
            <select className="field" value={f.icon} onChange={(e) => setF({ ...f, icon: e.target.value })}>
              {["sparkles", "moon", "shield", "camera", "trophy", "book", "users", "news"].map((o) => <option key={o} value={o}>{o}</option>)}
            </select>
          </div>
          <div className="flex gap-2 sm:col-span-2">
            <button onClick={save} className="btn-gold flex-1 !py-2.5">{editId ? "Update" : "Add wing"}</button>
            {editId && <button onClick={() => { setEditId(null); setF(empty); }} className="btn-ghost !py-2.5">Cancel</button>}
          </div>
        </div>
      </Row>
      {items.map((w) => (
        <Row key={w.id}>
          <div className="flex items-center gap-3">
            <div className="flex-1 min-w-0"><p className="font-bold text-[13.5px] truncate">{w.name}</p><p className="text-[11px]" style={{ color: "var(--ink-faint)" }}>{w.leaderName} · {w.memberCount} members</p></div>
            <button onClick={() => { setEditId(w.id); setF({ name: w.name, tagline: w.tagline, description: w.description, icon: w.icon, leaderName: w.leaderName, memberCount: w.memberCount, color: w.color }); }} className="w-8 h-8 grid place-items-center rounded-full border" style={{ borderColor: "var(--card-border)", color: "var(--ink-soft)" }}><Icon d={I.edit} size={14} /></button>
            <button onClick={() => del(w.id)} className="w-8 h-8 grid place-items-center rounded-full" style={{ background: "rgba(179,55,47,.12)", color: "#b3372f" }}><Icon d={I.trash} size={14} /></button>
          </div>
        </Row>
      ))}
    </div>
  );
}

function GalleryForm({ items, onChanged, onToast }: { items: GalleryItem[]; onChanged: () => void; onToast: (m: string, k?: "ok" | "err") => void }) {
  const [f, setF] = useState({ title: "", imageUrl: "", category: "Events" });
  const save = async () => {
    if (!f.title.trim() || !f.imageUrl.trim()) return onToast("Title and image URL required", "err");
    const r = await fetch("/api/gallery", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(f) });
    if (r.ok) { onToast("Photo added"); setF({ title: "", imageUrl: "", category: "Events" }); onChanged(); } else onToast("Save failed", "err");
  };
  const del = async (id: string) => {
    if (!confirm("Delete this photo?")) return;
    const r = await fetch(`/api/gallery?id=${id}`, { method: "DELETE" });
    if (r.ok) { onToast("Photo deleted"); onChanged(); } else onToast("Delete failed", "err");
  };
  return (
    <div className="space-y-3">
      <Row>
        <p className="font-bold text-[13px] mb-3">Add photo</p>
        <div className="grid sm:grid-cols-2 gap-2">
          <input className="field" placeholder="Caption" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />
          <input className="field" placeholder="Category" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })} />
          <input className="field sm:col-span-2" placeholder="Image URL (https://…)" value={f.imageUrl} onChange={(e) => setF({ ...f, imageUrl: e.target.value })} />
          <button onClick={save} className="btn-gold sm:col-span-2 !py-2.5">Add to gallery</button>
        </div>
        <p className="text-[11px] mt-2" style={{ color: "var(--ink-faint)" }}>Tip: use https://picsum.photos/seed/your-name/800/600 for instant demo photos.</p>
      </Row>
      <div className="grid grid-cols-2 gap-2">
        {items.map((g) => (
          <div key={g.id} className="relative rounded-xl overflow-hidden border group" style={{ borderColor: "var(--card-border)" }}>
            <img src={g.imageUrl} alt="" className="w-full h-28 object-cover" />
            <button onClick={() => del(g.id)} className="absolute top-1.5 right-1.5 w-7 h-7 grid place-items-center rounded-full text-white" style={{ background: "rgba(179,55,47,.9)" }}><Icon d={I.trash} size={12} /></button>
            <p className="text-[11px] font-semibold p-1.5 truncate" style={{ background: "var(--card)" }}>{g.title}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function NewsForm({ items, onChanged, onToast }: { items: NewsPost[]; onChanged: () => void; onToast: (m: string, k?: "ok" | "err") => void }) {
  const empty = { title: "", excerpt: "", content: "", imageUrl: "", author: "Union Media", pinned: false };
  const [f, setF] = useState(empty);
  const [editId, setEditId] = useState<string | null>(null);
  const save = async () => {
    if (!f.title.trim()) return onToast("Title required", "err");
    const method = editId ? "PUT" : "POST";
    const url = editId ? `/api/news?id=${editId}` : "/api/news";
    const r = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(f) });
    if (r.ok) { onToast(editId ? "Post updated" : "Post published"); setF(empty); setEditId(null); onChanged(); } else onToast("Save failed", "err");
  };
  const del = async (id: string) => {
    if (!confirm("Delete this post?")) return;
    const r = await fetch(`/api/news?id=${id}`, { method: "DELETE" });
    if (r.ok) { onToast("Post deleted"); onChanged(); } else onToast("Delete failed", "err");
  };
  return (
    <div className="space-y-3">
      <Row>
        <p className="font-bold text-[13px] mb-3">{editId ? "Edit post" : "New announcement"}</p>
        <div className="grid gap-2">
          <input className="field" placeholder="Headline" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />
          <input className="field" placeholder="Short excerpt" value={f.excerpt} onChange={(e) => setF({ ...f, excerpt: e.target.value })} />
          <textarea className="field" rows={4} placeholder="Full story…" value={f.content} onChange={(e) => setF({ ...f, content: e.target.value })} />
          <div className="grid sm:grid-cols-2 gap-2">
            <input className="field" placeholder="Image URL (optional)" value={f.imageUrl} onChange={(e) => setF({ ...f, imageUrl: e.target.value })} />
            <input className="field" placeholder="Author" value={f.author} onChange={(e) => setF({ ...f, author: e.target.value })} />
          </div>
          <label className="flex items-center gap-2 text-[13px] font-medium" style={{ color: "var(--ink-soft)" }}>
            <input type="checkbox" checked={f.pinned} onChange={(e) => setF({ ...f, pinned: e.target.checked })} className="w-4 h-4 accent-[#b07c2a]" /> Pin to top as featured
          </label>
          <div className="flex gap-2">
            <button onClick={save} className="btn-gold flex-1 !py-2.5">{editId ? "Update post" : "Publish post"}</button>
            {editId && <button onClick={() => { setEditId(null); setF(empty); }} className="btn-ghost !py-2.5">Cancel</button>}
          </div>
        </div>
      </Row>
      {items.map((p) => (
        <Row key={p.id}>
          <div className="flex items-center gap-3">
            <div className="flex-1 min-w-0"><p className="font-bold text-[13.5px] truncate">{p.pinned ? "📌 " : ""}{p.title}</p><p className="text-[11px] line-clamp-1" style={{ color: "var(--ink-faint)" }}>{p.excerpt}</p></div>
            <button onClick={() => { setEditId(p.id); setF({ title: p.title, excerpt: p.excerpt, content: p.content, imageUrl: p.imageUrl, author: p.author, pinned: p.pinned }); }} className="w-8 h-8 grid place-items-center rounded-full border" style={{ borderColor: "var(--card-border)", color: "var(--ink-soft)" }}><Icon d={I.edit} size={14} /></button>
            <button onClick={() => del(p.id)} className="w-8 h-8 grid place-items-center rounded-full" style={{ background: "rgba(179,55,47,.12)", color: "#b3372f" }}><Icon d={I.trash} size={14} /></button>
          </div>
        </Row>
      ))}
    </div>
  );
}
