import { pgTable, uuid, text, integer, timestamp, boolean } from "drizzle-orm/pg-core";

export const committeeMembers = pgTable("committee_members", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  role: text("role").notNull(),
  wing: text("wing").notNull().default("General"),
  bio: text("bio").notNull().default(""),
  photoUrl: text("photo_url").notNull().default(""),
  displayOrder: integer("display_order").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const wings = pgTable("wings", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  tagline: text("tagline").notNull().default(""),
  description: text("description").notNull().default(""),
  icon: text("icon").notNull().default("star"),
  leaderName: text("leader_name").notNull().default(""),
  memberCount: integer("member_count").notNull().default(0),
  color: text("color").notNull().default("#B07C2A"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const galleryItems = pgTable("gallery_items", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: text("title").notNull(),
  imageUrl: text("image_url").notNull(),
  category: text("category").notNull().default("Events"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const newsPosts = pgTable("news_posts", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: text("title").notNull(),
  excerpt: text("excerpt").notNull().default(""),
  content: text("content").notNull().default(""),
  imageUrl: text("image_url").notNull().default(""),
  author: text("author").notNull().default("Union Media"),
  pinned: boolean("pinned").notNull().default(false),
  publishedAt: timestamp("published_at").defaultNow(),
});

export const chatMessages = pgTable("chat_messages", {
  id: uuid("id").defaultRandom().primaryKey(),
  displayName: text("display_name").notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export type CommitteeMember = typeof committeeMembers.$inferSelect;
export type Wing = typeof wings.$inferSelect;
export type GalleryItem = typeof galleryItems.$inferSelect;
export type NewsPost = typeof newsPosts.$inferSelect;
export type ChatMessage = typeof chatMessages.$inferSelect;
