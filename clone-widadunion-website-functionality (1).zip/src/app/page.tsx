import WidadSite from "@/components/WidadSite";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return <WidadSite />;
}
