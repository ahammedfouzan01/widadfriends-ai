import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Widad Friends — Class 2 Union 2026 | 23rd Batch",
  description:
    "Worthy Individuals for Da'wa, Arts and Discipline. Official site of the Class 2 Union, 23rd Batch — BUAC Maniyyor. Committee, wings, gallery, news and union chat.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="antialiased">
        <div className="site-bg" />
        <div className="site-grid" />
        {children}
        <script
          dangerouslySetInnerHTML={{
            __html: `try{const t=localStorage.getItem('widad-theme');if(t==='dark')document.documentElement.classList.add('dark');}catch(e){}`,
          }}
        />
      </body>
    </html>
  );
}
