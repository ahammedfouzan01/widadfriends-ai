import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { committeeMembers, wings, galleryItems, newsPosts, chatMessages } from "@/db/schema";
import { sql } from "drizzle-orm";
import { ensureSeeded } from "@/lib/seed";

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "widad2026";

export async function GET() {
  try {
    await ensureSeeded();
    const [c, w, g, n, ch] = await Promise.all([
      db.execute(sql`select count(*)::int as c from ${committeeMembers}`),
      db.execute(sql`select count(*)::int as c from ${wings}`),
      db.execute(sql`select count(*)::int as c from ${galleryItems}`),
      db.execute(sql`select count(*)::int as c from ${newsPosts}`),
      db.execute(sql`select count(*)::int as c from ${chatMessages}`),
    ]);
    const num = (r: { rows: Record<string, unknown>[] }) => Number((r.rows[0] as { c?: number })?.c ?? 0);
    return NextResponse.json({ ok: true, counts: { committee: num(c), wings: num(w), gallery: num(g), news: num(n), chat: num(ch) } });
  } catch (e) {
    return NextResponse.json({ ok: false, error: "db-unready" }, { status: 200 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const b = await req.json();
    if (b.action === "login") {
      if (String(b.password ?? "") === ADMIN_PASSWORD) return NextResponse.json({ ok: true });
      return NextResponse.json({ ok: false, error: "Wrong password" }, { status: 401 });
    }
    if (b.action === "reseed") {
      await db.execute(sql`delete from ${chatMessages}`);
      await db.execute(sql`delete from ${newsPosts}`);
      await db.execute(sql`delete from ${galleryItems}`);
      await db.execute(sql`delete from ${committeeMembers}`);
      await db.execute(sql`delete from ${wings}`);
      await ensureSeeded();
      return NextResponse.json({ ok: true });
    }
    return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  } catch {
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
