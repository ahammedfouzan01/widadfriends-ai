import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { chatMessages } from "@/db/schema";
import { asc, eq } from "drizzle-orm";

const BANNED = ["http://", "https://", "<script", "porn", "xxx"];

export async function GET() {
  try {
    const messages = await db.select().from(chatMessages).orderBy(asc(chatMessages.createdAt)).limit(150);
    return NextResponse.json({ messages });
  } catch {
    return NextResponse.json({ messages: [] });
  }
}

export async function POST(req: NextRequest) {
  try {
    const b = await req.json();
    const name = String(b.displayName ?? "").trim().slice(0, 30);
    const message = String(b.message ?? "").trim().slice(0, 500);
    if (!name) return NextResponse.json({ error: "Name required" }, { status: 400 });
    if (!message) return NextResponse.json({ error: "Message is empty" }, { status: 400 });
    const low = message.toLowerCase();
    if (BANNED.some((w) => low.includes(w))) return NextResponse.json({ error: "Links and spam are not allowed in chat" }, { status: 400 });
    const [row] = await db.insert(chatMessages).values({ displayName: name, message }).returning();
    // keep table lean — drop older than 300
    try {
      await db.execute(`delete from chat_messages where id not in (select id from chat_messages order by created_at desc limit 300)`);
    } catch {}
    return NextResponse.json({ message: row });
  } catch {
    return NextResponse.json({ error: "Could not send" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const id = new URL(req.url).searchParams.get("id");
    if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });
    await db.delete(chatMessages).where(eq(chatMessages.id, id));
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Delete failed" }, { status: 500 });
  }
}
