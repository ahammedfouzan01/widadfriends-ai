import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { committeeMembers } from "@/db/schema";
import { asc, eq } from "drizzle-orm";

export async function GET() {
  try {
    const members = await db.select().from(committeeMembers).orderBy(asc(committeeMembers.displayOrder));
    return NextResponse.json({ members });
  } catch (e) {
    return NextResponse.json({ members: [], error: "db-unready" }, { status: 200 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const b = await req.json();
    if (!b.name?.trim() || !b.role?.trim()) return NextResponse.json({ error: "Name and role required" }, { status: 400 });
    const [row] = await db.insert(committeeMembers).values({
      name: String(b.name).slice(0, 80),
      role: String(b.role).slice(0, 80),
      wing: String(b.wing ?? "General").slice(0, 80),
      bio: String(b.bio ?? "").slice(0, 1000),
      photoUrl: String(b.photoUrl ?? "").slice(0, 500),
      displayOrder: Number(b.displayOrder) || 0,
    }).returning();
    return NextResponse.json({ member: row });
  } catch {
    return NextResponse.json({ error: "Save failed" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const id = new URL(req.url).searchParams.get("id");
    if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });
    const b = await req.json();
    const [row] = await db.update(committeeMembers).set({
      name: String(b.name).slice(0, 80),
      role: String(b.role).slice(0, 80),
      wing: String(b.wing ?? "General").slice(0, 80),
      bio: String(b.bio ?? "").slice(0, 1000),
      photoUrl: String(b.photoUrl ?? "").slice(0, 500),
      displayOrder: Number(b.displayOrder) || 0,
    }).where(eq(committeeMembers.id, id)).returning();
    return NextResponse.json({ member: row });
  } catch {
    return NextResponse.json({ error: "Update failed" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const id = new URL(req.url).searchParams.get("id");
    if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });
    await db.delete(committeeMembers).where(eq(committeeMembers.id, id));
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Delete failed" }, { status: 500 });
  }
}
