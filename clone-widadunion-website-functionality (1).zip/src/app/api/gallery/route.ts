import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { galleryItems } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  try {
    const items = await db.select().from(galleryItems).orderBy(desc(galleryItems.createdAt));
    return NextResponse.json({ items });
  } catch {
    return NextResponse.json({ items: [] });
  }
}

export async function POST(req: NextRequest) {
  try {
    const b = await req.json();
    if (!b.title?.trim() || !b.imageUrl?.trim()) return NextResponse.json({ error: "Title and image required" }, { status: 400 });
    const [row] = await db.insert(galleryItems).values({
      title: String(b.title).slice(0, 120),
      imageUrl: String(b.imageUrl).slice(0, 800),
      category: String(b.category ?? "Events").slice(0, 40),
    }).returning();
    return NextResponse.json({ item: row });
  } catch {
    return NextResponse.json({ error: "Save failed" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const id = new URL(req.url).searchParams.get("id");
    if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });
    await db.delete(galleryItems).where(eq(galleryItems.id, id));
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Delete failed" }, { status: 500 });
  }
}
